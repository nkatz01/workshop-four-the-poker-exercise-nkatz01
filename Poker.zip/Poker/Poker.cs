﻿namespace Poker
{
    internal class Poker
    {
        static void Main()
        {
            
        }
    }
}