namespace StageThree
{
    public enum CardSuit
    {
        Spades,
        Diamonds,
        Clubs,
        Hearts
    }
}