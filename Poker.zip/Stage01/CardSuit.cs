namespace CsharpPoker
{
    public enum CardSuit
    {
        Spades,
        Diamonds,
        Clubs,
        Hearts
    }
}