﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;

namespace StageFinalRefactor
{
    public static class EvalExtensions
    {
        public static IEnumerable<KeyValuePair<CardValue, int>> ToKindAndQuantities(this IEnumerable<Card> cards)
        {
            var dict = new ConcurrentDictionary<CardValue, int>();
            foreach (var card in cards) dict.AddOrUpdate(card.Value, 1, (cardValue, quantity) => ++quantity);

            return dict;
        }

        public static IEnumerable<TResult> SelectConsecutive<TSource, TResult>(this IEnumerable<TSource> source,
            Func<TSource, TSource, TResult> selector)
        {
            var index = -1;
            foreach (var element in source.Take(source.Count() - 1))
            {
                checked
                {
                    index++;
                }

                yield return selector(element, source.ElementAt(index + 1));
            }
        }

        //public static HandRank Score(this Hand hand) => new FiveCardPokerScorer().GetScore(hand);
    }
}