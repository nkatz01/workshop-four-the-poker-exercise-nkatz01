using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Poker.Tests
{
    [TestClass]
    public class PokerTests
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}